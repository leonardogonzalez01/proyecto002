export const initialState = {
  characters: [],
  charactersLoading: null,
  charactersError: null
};