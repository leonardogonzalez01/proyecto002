export const initialState = {
  users: [],
  usersLoading: null,
  usersError: null
};