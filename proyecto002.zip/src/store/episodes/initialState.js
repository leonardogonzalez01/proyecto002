export const initialState = {
  episodes: [],
  episodesLoading: null,
  episodesError: null,
  episodesInit:null,
};