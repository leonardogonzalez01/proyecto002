import React from 'react';

const Urlepisode = () => {
    return 'https://rickandmortyapi.com/api/episode/';
};

export default Urlepisode;
