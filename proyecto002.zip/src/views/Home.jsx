import React from 'react';
import Layout from '../components/commons/Layout/Layout';

const Home = () => {
    return (
        <Layout>

            hola, soy el home
        </Layout>
    );
};


export default Home;